
    @extends('principal');
    @section('title','Editar Cliente');
    @section('content');
	<h1>Editar Cliente - <?php echo $id;?></h1>
	<form>
		<div class="input-group input-group-lg">
		<span class="input-group-addon" id="sizing-addon1">Nome</span>
		<input type="text" class="form-control" placeholder="Nome" aria-describedby="sizing-addon1">
	    </div>

	    <div class="input-group input-group-lg">
	    <span class="input-group-addon1">@</span>
	    <input type="text" class="form-control" placeholder="E-mail" aria-describedby="sizing-addon1">
	
		<input type="submit"value="cadastrar">
	</form>
		<a href="<?php echo action("ClienteController@listar2");?>">Listar Cliente</a>
		<a href="{{action ClienteController@listar2}}">Listar Cliente</a>
    @stop
   