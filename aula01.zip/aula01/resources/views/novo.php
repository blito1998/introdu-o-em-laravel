<!DOCTYPE html>
<html>
<head>
	<title>Novo Cliente</title>
</head>

<body>
	<h1>Novo Cliente </h1>
	<form>
		Nome: <input type="text"><br>
		E-mail: <input type="text"><br>
		Telefone: <input type="text"><br>
		<input type="submit"value="cadastrar">
	</form>
	<a href="<?php echo action("ClienteController@listar");?>">Listar Cliente</a>
</body>
</html>