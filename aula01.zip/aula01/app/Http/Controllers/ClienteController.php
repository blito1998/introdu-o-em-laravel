<?php
    namespace App\Http\Controllers;

    use request;


 class ClienteController extends Controller{
 	public function listar() {
 		$data = date("Y-m-d");

 		if ($data > '2016-09-28'){
 			$msg = "Incrição finalizada!";

 		}else {
 			$msg = "Incrição em aberto!";
 		}

 		return view("listar")->with("msg",$msg);

 		
 	}
 	public function listar2(){
 		$nomes = array(1=>"Joao",2=>"Maria",3=>"Pedro");
 		return view('listar2')->with('nomes',$nomes)->with('nome','RL system');
 	}
 	public function editar($id){
 		/*if (request::hash('id')){
 		$id = request::input("id");	
        }else{
        	$id=0;
        }*/

        $id = request::input('id',0);

        //URL
        $url = request::path();
        $url = request::url();

        //$id = request::route('id');
 		

 		return view('editar')->with("id",$id)->with("url",$url);

 	}

 	public function novo(){
 		if (view()->exists('novo')){
 			return view("novo");
 		}else {
 			return view('welcome');
 		}
 		
 	}
 }
?>